from flask import Flask, render_template, request, jsonify
import zipfile
import re
import io
from collections import Counter
from datetime import datetime, timedelta
import os

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB

def parse_whatsapp_chat(text):
    """Parse WhatsApp exported chat text into messages."""
    # Support multiple date formats used by WhatsApp
    patterns = [
        r'\[(\d{2}/\d{2}/\d{4}),\s*(\d{2}:\d{2}:\d{2})\]\s+([^:]+):\s+(.*)',  # [DD/MM/YYYY, HH:MM:SS]
        r'(\d{2}/\d{2}/\d{4}),\s*(\d{2}:\d{2})\s+-\s+([^:]+):\s+(.*)',         # DD/MM/YYYY, HH:MM - name:
        r'(\d{1,2}/\d{1,2}/\d{2,4}),\s*(\d{1,2}:\d{2})\s*[ap]m\s+-\s+([^:]+):\s+(.*)',  # US format
        r'\[(\d{2}/\d{2}/\d{4})\s+(\d{2}:\d{2}:\d{2})\]\s+([^:]+):\s+(.*)',  # [DD/MM/YYYY HH:MM:SS]
    ]
    
    messages = []
    lines = text.split('\n')
    current_msg = None
    
    for line in lines:
        matched = False
        for pattern in patterns:
            m = re.match(pattern, line)
            if m:
                if current_msg:
                    messages.append(current_msg)
                date_str, time_str, sender, content = m.group(1), m.group(2), m.group(3).strip(), m.group(4).strip()
                try:
                    if '/' in date_str:
                        parts = date_str.split('/')
                        if len(parts[2]) == 2:
                            parts[2] = '20' + parts[2]
                        dt = datetime.strptime(f"{'/'.join(parts)} {time_str.split(':')[0]}:{time_str.split(':')[1]}", "%d/%m/%Y %H:%M")
                    else:
                        dt = None
                except:
                    dt = None
                
                current_msg = {'date': dt, 'sender': sender, 'content': content, 'raw': line}
                matched = True
                break
        
        if not matched and current_msg:
            current_msg['content'] += '\n' + line
    
    if current_msg:
        messages.append(current_msg)
    
    return messages

def is_sticker_or_media(content):
    """Detect stickers, images, videos, audios."""
    media_terms = [
        '<figurinha omitida>', '<sticker omitted>', 'figurinha omitida',
        '<imagem omitida>', '<image omitted>', 'imagem omitida',
        '<vídeo omitido>', '<video omitted>', 'vídeo omitido',
        '<áudio omitido>', '<audio omitted>', 'áudio omitido',
        '<arquivo omitido>', '<file omitted>',
        '<mídia omitida>', '<media omitted>',
        '.webp', '.opus', '.mp4', '.jpg', '.jpeg', '.png'
    ]
    content_lower = content.lower()
    return any(term in content_lower for term in media_terms)

def is_sticker(content):
    content_lower = content.lower()
    return '<figurinha omitida>' in content_lower or '<sticker omitted>' in content_lower or 'figurinha omitida' in content_lower

def analyze_chat(messages):
    if not messages:
        return None
    
    # Get unique senders (ignore system messages)
    senders = [m['sender'] for m in messages if not any(
        sys in m['content'].lower() for sys in [
            'as mensagens', 'messages to this group', 'changed', 'added', 'removed',
            'cifrado de ponta a ponta', 'end-to-end encrypted', 'security code'
        ]
    )]
    sender_counts = Counter(senders)
    
    # Top 2 senders
    top_senders = sender_counts.most_common(2)
    if len(top_senders) < 2:
        return {'error': 'Não encontrei 2 participantes na conversa. Verifique o arquivo.'}
    
    person1 = top_senders[0][0]
    person2 = top_senders[1][0]
    
    # Filter real messages only
    real_messages = [m for m in messages if m['sender'] in [person1, person2]]
    
    # Word frequency per person
    def get_words(sender):
        words = []
        for m in real_messages:
            if m['sender'] == sender and not is_sticker_or_media(m['content']):
                # Clean and tokenize
                text = m['content'].lower()
                text = re.sub(r'[^\w\sáàãâéêíóõôúüçñ]', ' ', text, flags=re.UNICODE)
                ws = [w for w in text.split() if len(w) > 2]
                # Remove common stop words
                stopwords = {'que', 'não', 'uma', 'com', 'por', 'para', 'como', 'mas',
                           'mais', 'você', 'voce', 'isso', 'esse', 'essa', 'ele', 'ela',
                           'tem', 'era', 'são', 'foi', 'ser', 'ter', 'vai', 'vou', 'sim',
                           'não', 'nao', 'meu', 'minha', 'seu', 'sua', 'the', 'and', 'for',
                           'que', 'aqui', 'ali', 'agora', 'então', 'entao', 'tudo', 'muito',
                           'também', 'tambem', 'quando', 'porque', 'nada', 'assim', 'ainda',
                           'bem', 'bom', 'boa', 'aqui', 'lá', 'pro', 'pra', 'num', 'numa',
                           'umas', 'uns', 'uns', 'dos', 'das', 'nos', 'nas', 'pelo', 'pela',
                           'pelos', 'pelas', 'esse', 'essa', 'esses', 'essas', 'este', 'esta',
                           'estes', 'estas', 'aquele', 'aquela', 'isso', 'isto', 'aquilo',
                           'mesmo', 'mesma', 'outros', 'outras', 'outro', 'outra', 'cada',
                           'todo', 'toda', 'todos', 'todas', 'tipo', 'coisa', 'ver', 'faz',
                           'fica', 'só', 'até', 'aí', 'já', 'né', 'acho', 'sei',
                           'haha', 'kkk', 'kk', 'rsrs', 'hauha', 'hahaha'}
                ws = [w for w in ws if w not in stopwords]
                words.extend(ws)
        return Counter(words)
    
    p1_words = get_words(person1)
    p2_words = get_words(person2)
    
    # Sticker counts
    def count_stickers(sender):
        return sum(1 for m in real_messages if m['sender'] == sender and is_sticker(m['content']))
    
    p1_stickers = count_stickers(person1)
    p2_stickers = count_stickers(person2)
    
    # Message counts
    p1_msgs = sender_counts[person1]
    p2_msgs = sender_counts[person2]
    
    # Conversation streaks (consecutive days)
    dates = sorted(set(
        m['date'].date() for m in real_messages if m['date']
    ))
    
    streaks = []
    if dates:
        streak_start = dates[0]
        streak_len = 1
        for i in range(1, len(dates)):
            if (dates[i] - dates[i-1]).days == 1:
                streak_len += 1
            else:
                streaks.append((streak_start, dates[i-1], streak_len))
                streak_start = dates[i]
                streak_len = 1
        streaks.append((streak_start, dates[-1], streak_len))
    
    longest_streak = max(streaks, key=lambda x: x[2]) if streaks else None
    current_streak = None
    if streaks and streaks[-1][1] >= (datetime.now().date() - timedelta(days=1)):
        current_streak = streaks[-1][2]
    
    # Total days
    total_days = len(dates)
    first_date = dates[0] if dates else None
    last_date = dates[-1] if dates else None
    
    return {
        'person1': {'name': person1, 'msgs': p1_msgs, 'top_word': p1_words.most_common(5), 'stickers': p1_stickers},
        'person2': {'name': person2, 'msgs': p2_msgs, 'top_word': p2_words.most_common(5), 'stickers': p2_stickers},
        'total_msgs': p1_msgs + p2_msgs,
        'longest_streak': {'days': longest_streak[2], 'start': str(longest_streak[0]), 'end': str(longest_streak[1])} if longest_streak else None,
        'current_streak': current_streak,
        'total_days': total_days,
        'first_date': str(first_date) if first_date else None,
        'last_date': str(last_date) if last_date else None,
        'streaks_count': len(streaks),
    }

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    if 'file' not in request.files:
        return jsonify({'error': 'Nenhum arquivo enviado'}), 400
    
    file = request.files['file']
    if not file.filename.endswith('.zip'):
        return jsonify({'error': 'Por favor, envie um arquivo .zip exportado do WhatsApp'}), 400
    
    try:
        zip_data = file.read()
        with zipfile.ZipFile(io.BytesIO(zip_data)) as z:
            txt_files = [f for f in z.namelist() if f.endswith('.txt')]
            if not txt_files:
                return jsonify({'error': 'Nenhum arquivo .txt encontrado no zip. Exporte a conversa sem mídia.'}), 400
            
            # Read the chat file
            with z.open(txt_files[0]) as f:
                try:
                    content = f.read().decode('utf-8')
                except:
                    content = f.read().decode('latin-1')
        
        messages = parse_whatsapp_chat(content)
        if not messages:
            return jsonify({'error': 'Não consegui ler as mensagens. Verifique se o arquivo é uma exportação do WhatsApp.'}), 400
        
        result = analyze_chat(messages)
        if result and 'error' in result:
            return jsonify(result), 400
        
        return jsonify(result)
    
    except zipfile.BadZipFile:
        return jsonify({'error': 'Arquivo zip inválido ou corrompido'}), 400
    except Exception as e:
        return jsonify({'error': f'Erro ao processar: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)

@app.errorhandler(413)
def too_large(e):
    return jsonify({'error': 'Arquivo muito grande. Tente exportar a conversa sem mídia (somente texto).'}), 413
